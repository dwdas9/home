This setup provides a full Hive warehouse with persistent data stored in Docker volumes. The metastore and PostgreSQL containers can be reused indefinitely once installed. However, the HiveServer2 container must be freshly installed every time, as restarting it results in a "process already running, kill it first" error.

To set up the environment, just double-click `setup.bat`, ensuring Docker Desktop is running. Optionally, you can run `optional.bat` to install additional utilities inside the containers after setup.

### Setup details:
1. Creates a Docker volume for the warehouse.
2. Installs PostgreSQL, metastore, and HiveServer2 containers, following the official Hive instructions with minimal customization.

Hive version apache/hive:4.0.0-alpha-2

POSTGRES_USER=hive -e POSTGRES_PASSWORD=password

The setup allows creating Hive tables directly from Spark using the following example:

```python
from pyspark.sql import SparkSession

spark = SparkSession.builder \
    .appName("Connecting to Hive") \
    .config("spark.sql.catalogImplementation", "hive") \
    .config("hive.metastore.uris", "thrift://metastore:9083") \
    .enableHiveSupport() \
    .getOrCreate()

data = [("Rambo", 30), ("Titanic", 25)]
df = spark.createDataFrame(data, ["name", "release"])

df.write.mode("overwrite").format("parquet").saveAsTable("default.kollywood_parquet")
```

All data is stored in the `warehouse` Docker volume. To view the volume data, you must use root access as Docker Desktop shows 0 bytes due to permission restrictions.

The metastore and HiveServer2 use Apache Hive containers configured as follows:

- User: `hive`
- Workdir: `/opt/hive`
- Exposed Ports: `10000`, `10002`, `9083`
- Entrypoint: `["sh", "-c", "/entrypoint.sh"]`

To connect to HiveServer2 and run queries via Beeline:

```bash
docker exec -it hiveserver2 beeline -u 'jdbc:hive2://hiveserver2:10000/'
```

For more details:
- [Apache Hive](https://hive.apache.org)
- [Apache Hive Dockerfile](https://github.com/apache/hive/blob/master/packaging/src/docker/Dockerfile)