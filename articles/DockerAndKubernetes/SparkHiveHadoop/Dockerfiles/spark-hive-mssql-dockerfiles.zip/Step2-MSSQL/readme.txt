## Fully Working Dockerfile and Docker Compose. Either run.bat or follow the commands below.

### Instructions

**Open Command Prompt and navigate to this folder, then run the following commands:**

```sh
docker-compose -p mssql build
docker-compose -p mssql up -d
```

### Additional Setup for MSSQL Server

**Navigate to this folder and run these commands once the MSSQL server is up:**

```sh
docker cp init-db.sql mssql:/init-db.sql
docker exec -it mssql /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P Passw0rd -i /init-db.sql
```

**Note:** Do not try to map any folder for the MSSQL server like `mssql-data`. It will create this error: `2024-06-20 00:51:41 ** ERROR: LSA initialization failed; ExitCode=0xc000004b`.
