## Fully Working Dockerfile and Docker Compose. Creates a fully operational bitnami spark cluster.

## Either click the run.bat or run these following commands in CMD:

```sh
docker-compose -p bitnami-spark-cluster build
docker-compose -p bitnami-spark-cluster up -d
```

## Result
- Access Spark Master at: [http://localhost:8080/](http://localhost:8080/)
- Access Spark Worker 1 at: [http://localhost:8081/](http://localhost:8081/)
- Access Spark Worker 2 at: [http://localhost:8082/](http://localhost:8082/)