- The setup process is one of the most complex and error-prone, but it's finally successful. Initially, the metastore starts with Derby. Then, we change the `/entrypoint.sh` to use MSSQL, which is the tricky part.
- First, click `run.bat` to start the container. WAIT for 15 seconds to allow the container to start. The script will then copy the `hive-site.xml` file to the container using `docker cp hive-site.xml hive-metastore:/opt/hive/conf/`.
- Next, access the container files and change the `DB_DRIVER` value from Derby to MSSQL in `/entrypoint.sh` by modifying `${DB_DRIVER:=mssql}`.
- This step will change the file permissions. Log into the terminal, switch to the superuser with `su` (password: Passw0rd), and enter:

```sh
chmod 777 /entrypoint.sh
```

- Finally, restart the container.
- Now, the container will connect to the MSSQL server. Ensure the MSSQL server is running, the `hive_metastore` database is created, and the user `dwdas` is set up.

---The dockerfile creates the su user with password Passw0rd. This is required.