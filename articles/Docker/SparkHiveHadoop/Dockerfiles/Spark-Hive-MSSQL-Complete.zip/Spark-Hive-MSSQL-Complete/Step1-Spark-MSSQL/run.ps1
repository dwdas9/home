# Change directory to the folder containing this script
cd $PSScriptRoot

# Create the Docker volumes
docker volume create hive-metastore
docker volume create hive-warehouse

# Build and run the Docker Compose services
docker-compose -p bitnami-spark-cluster build
docker-compose -p bitnami-spark-cluster up -d

# Copy the init-db.sql file to the MSSQL container
docker cp init-db.sql mssql:/init-db.sql

# Execute the SQL script to initialize the database
docker exec -it mssql /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P Passw0rd -i /init-db.sql
