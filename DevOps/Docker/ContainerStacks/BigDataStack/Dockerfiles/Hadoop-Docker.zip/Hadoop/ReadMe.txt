# This is a fully running Haddop. Full-fledged Hadoop. Tested. Works everytime.
# Start the docker desktop. # CD to this folder. # Run the two commands.



docker-compose build
docker-compose up -d