#!/bin/bash
# Format namenode if necessary
if [ "$1" == "namenode" ]; then
  $HADOOP_HOME/bin/hdfs namenode -format -force -nonInteractive
fi
# Start SSH service
service ssh start
# Start Hadoop service based on the role
if [ "$1" == "namenode" ]; then
  $HADOOP_HOME/sbin/hadoop-daemon.sh start namenode
elif [ "$1" == "datanode" ]; then
  $HADOOP_HOME/sbin/hadoop-daemon.sh start datanode
elif [ "$1" == "secondarynamenode" ]; then
  $HADOOP_HOME/sbin/hadoop-daemon.sh start secondarynamenode
elif [ "$1" == "resourcemanager" ]; then
  $HADOOP_HOME/sbin/yarn-daemon.sh start resourcemanager
elif [ "$1" == "nodemanager" ]; then
  $HADOOP_HOME/sbin/yarn-daemon.sh start nodemanager
elif [ "$1" == "historyserver" ]; then
  $HADOOP_HOME/sbin/mr-jobhistory-daemon.sh start historyserver
fi
# Keep the container running
tail -f /dev/null
