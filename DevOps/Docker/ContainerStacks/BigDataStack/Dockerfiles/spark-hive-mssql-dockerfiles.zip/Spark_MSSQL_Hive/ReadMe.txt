---
Solid full SparkCluster-HiveWithMSSQL setup
---
Works every time by just running three bat files!
---