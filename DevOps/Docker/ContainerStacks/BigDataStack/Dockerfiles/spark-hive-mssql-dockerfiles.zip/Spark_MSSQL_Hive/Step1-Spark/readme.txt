## Fully Working Dockerfile and Docker Compose. Creates a fully operational bitnami spark cluster.
## Either click the run.bat or run these following commands in CMD:

```sh
docker-compose -p bitnami-spark-cluster build
docker-compose -p bitnami-spark-cluster up -d
```

## Result
- Access Spark Master at: [http://localhost:8080/](http://localhost:8080/)
- Access Spark Worker 1 at: [http://localhost:8081/](http://localhost:8081/)
- Access Spark Worker 2 at: [http://localhost:8082/](http://localhost:8082/)

## Reference
Official Dockerfile			: https://github.com/bitnami/containers/blob/main/bitnami/spark/3.5/debian-12/Dockerfile
From github				: https://hub.docker.com/r/bitnami/spark/dockerfile

The container runs with user 1001
Three users, root, 1001, spark. All password Passw0rd.