CREATE DATABASE hive_metastore;
GO
CREATE LOGIN dwdas WITH PASSWORD='Passw0rd';
GO
USE hive_metastore;
GO
CREATE USER dwdas FOR LOGIN dwdas;
GO
ALTER ROLE db_owner ADD MEMBER dwdas;
GO
