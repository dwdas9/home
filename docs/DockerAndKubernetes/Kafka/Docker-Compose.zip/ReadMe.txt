Aug 2024: Confluent Kafka 6 and all related components on Docker.
---
This is the best fully-working production-grade setup. If you face any issue, fix it, but don’t change this file. This is a customized version of the original Docker Compose file from the official site: https://github.com/confluentinc/cp-all-in-one/tree/7.5.0-post/cp-all-in-one. 

It works perfectly. Kafka can be very complicated, but this setup is fully functional. All local ports are set to rare numbers to avoid any conflicts.

---

Open Command Prompt and navigate to this folder.

Run `docker-compose up -d`

That’s it! You will see 9 containers in your Docker Desktop.